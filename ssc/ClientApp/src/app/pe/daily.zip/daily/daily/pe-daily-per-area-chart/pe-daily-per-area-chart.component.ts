import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pe-daily-per-area-chart',
  templateUrl: './pe-daily-per-area-chart.component.html',
  styleUrls: ['./pe-daily-per-area-chart.component.scss']
})
export class PeDailyPerAreaChartComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
