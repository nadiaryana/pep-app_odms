import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pe-daily-zonechart-list',
  templateUrl: './pe-daily-zonechart-list.component.html',
  styleUrls: ['./pe-daily-zonechart-list.component.scss']
})
export class PeDailyZonechartListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
