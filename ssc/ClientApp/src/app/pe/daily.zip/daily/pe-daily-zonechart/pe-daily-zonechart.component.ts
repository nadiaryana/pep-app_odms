import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pe-daily-zonechart',
  templateUrl: './pe-daily-zonechart.component.html',
  styleUrls: ['./pe-daily-zonechart.component.scss']
})
export class PeDailyZonechartComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
