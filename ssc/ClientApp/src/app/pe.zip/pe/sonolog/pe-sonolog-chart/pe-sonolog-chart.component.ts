import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pe-sonolog-chart',
  templateUrl: './pe-sonolog-chart.component.html',
  styleUrls: ['./pe-sonolog-chart.component.scss']
})
export class PeSonologChartComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
